"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import type { Chat } from "@/types/chat"
import { Button } from "@/components/ui/button"
import { Menu, Settings, Send } from "lucide-react"
import { WelcomeScreen } from "@/components/welcome-screen"
import { MessageList } from "@/components/message-list"
import { DisclaimerNotice } from "@/components/disclaimer-notice"
import { cn } from "@/lib/utils"

interface ChatInterfaceProps {
  chat?: Chat
  onSendMessage: (content: string) => void
  onToggleSidebar: () => void
  onNewChat: () => void
}

export function ChatInterface({ chat, onSendMessage, onToggleSidebar, onNewChat }: ChatInterfaceProps) {
  const [input, setInput] = useState("")
  const [showDisclaimer, setShowDisclaimer] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [chat?.messages])

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`
    }
  }, [input])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    onSendMessage(input.trim())
    setInput("")
    setShowDisclaimer(true)
  }

  const handleSuggestedQuestion = (question: string) => {
    onSendMessage(question)
    setShowDisclaimer(true)
  }

  return (
    <div className="flex-1 flex flex-col h-screen">
      {/* Header */}
      <header className="h-16 border-b border-border bg-background flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={onToggleSidebar}>
            <Menu className="w-5 h-5" />
          </Button>
          <div>
            <h2 className="text-lg font-semibold text-foreground">MedWise Health Assistant</h2>
            <p className="text-sm text-muted-foreground">Ask me anything about your health</p>
          </div>
        </div>
        <Button variant="ghost" size="icon">
          <Settings className="w-5 h-5" />
        </Button>
      </header>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto">
        {!chat || chat.messages.length === 0 ? (
          <WelcomeScreen onSelectQuestion={handleSuggestedQuestion} />
        ) : (
          <MessageList messages={chat.messages} />
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <div className="border-t border-border bg-background shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <div className="max-w-5xl mx-auto px-6 py-5">
          {showDisclaimer && <DisclaimerNotice />}

          <form onSubmit={handleSubmit} className="relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSubmit(e)
                }
              }}
              placeholder="Ask me anything about your health..."
              className="w-full resize-none rounded-3xl border-2 border-input bg-background px-5 py-3 pr-14 text-[15px] focus:border-primary focus:outline-none transition-colors"
              rows={1}
            />
            <Button
              type="submit"
              size="icon"
              disabled={!input.trim()}
              className={cn(
                "absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full transition-all",
                input.trim()
                  ? "bg-primary hover:bg-primary/90 hover:scale-105 active:scale-95"
                  : "bg-muted text-muted-foreground cursor-not-allowed",
              )}
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
