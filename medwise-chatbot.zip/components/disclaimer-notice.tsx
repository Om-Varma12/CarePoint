import { Info } from "lucide-react"

export function DisclaimerNotice() {
  return (
    <div className="mb-4 flex items-start gap-3 bg-[#FEF3C7] border-l-3 border-l-warning px-4 py-3 rounded-lg">
      <Info className="w-5 h-5 text-[#92400E] flex-shrink-0 mt-0.5" />
      <p className="text-sm text-[#92400E]">
        MedWise provides general health information. Always consult a healthcare professional for medical advice.
      </p>
    </div>
  )
}
